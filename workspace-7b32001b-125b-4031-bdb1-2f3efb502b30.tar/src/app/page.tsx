"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Send, CheckCircle, Loader2, FileText } from "lucide-react";

const TASK_TYPES = [
  "Дизайн",
  "Программирование",
  "Копирайтинг",
  "Перевод",
  "Видео/Монтаж",
  "SMM / Маркетинг",
  "Аналитика",
  "Администрирование",
  "Другое",
];

interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
}

declare global {
  interface Window {
    Telegram?: {
      WebApp: {
        ready: () => void;
        expand: () => void;
        close: () => void;
        MainButton: {
          text: string;
          show: () => void;
          hide: () => void;
          onClick: (fn: () => void) => void;
        };
        initDataUnsafe: {
          user?: TelegramUser;
        };
        colorScheme: "light" | "dark";
        themeParams: Record<string, string>;
      };
    };
  }
}

export default function Home() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isTelegram, setIsTelegram] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    username: "",
    taskType: "",
    description: "",
    budget: "",
    deadline: "",
    contacts: "",
  });

  // Initialize Telegram WebApp
  useEffect(() => {
    if (window.Telegram?.WebApp) {
      const tg = window.Telegram.WebApp;
      tg.ready();
      tg.expand();
      setIsTelegram(true);

      // Pre-fill from Telegram user data
      const user = tg.initDataUnsafe?.user;
      if (user) {
        setFormData((prev) => ({
          ...prev,
          name: prev.name || `${user.first_name}${user.last_name ? " " + user.last_name : ""}`,
          username: prev.username || user.username || "",
        }));
      }
    }
  }, []);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.taskType || !formData.description.trim()) {
      toast({
        title: "Ошибка",
        description: "Заполните обязательные поля: имя, тип задания и описание",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch("/api/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Произошла ошибка");
      }

      setIsSuccess(true);
      toast({
        title: "Готово! ✅",
        description: "Анкета успешно отправлена",
      });

      // Close Telegram Mini App after delay
      if (isTelegram) {
        setTimeout(() => {
          window.Telegram?.WebApp?.close();
        }, 2000);
      }
    } catch (err) {
      toast({
        title: "Ошибка",
        description: err instanceof Error ? err.message : "Попробуйте ещё раз",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white flex items-center justify-center p-4">
        <Card className="w-full max-w-sm border-0 shadow-lg">
          <CardContent className="flex flex-col items-center gap-4 pt-8 pb-8">
            <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <div className="text-center">
              <h2 className="text-xl font-bold text-slate-900">Отправлено!</h2>
              <p className="text-sm text-slate-500 mt-2">
                Ваша анкета принята. Мы скоро свяжемся с вами.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-md border-b border-slate-200/60">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-slate-900 flex items-center justify-center flex-shrink-0">
            <FileText className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-base font-bold text-slate-900">Анкета</h1>
            <p className="text-xs text-slate-500">Заявка на доп задание</p>
          </div>
        </div>
      </header>

      {/* Form */}
      <main className="max-w-lg mx-auto px-4 py-5">
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Name */}
          <div className="space-y-2">
            <Label htmlFor="name" className="text-sm font-medium text-slate-700">
              Имя <span className="text-red-500">*</span>
            </Label>
            <Input
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Ваше имя"
              required
              className="h-11 bg-white border-slate-200 rounded-xl focus-visible:ring-slate-400"
            />
          </div>

          {/* Username */}
          <div className="space-y-2">
            <Label htmlFor="username" className="text-sm font-medium text-slate-700">
              Telegram username
            </Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm">
                @
              </span>
              <Input
                id="username"
                name="username"
                value={formData.username}
                onChange={handleChange}
                placeholder="username"
                className="h-11 bg-white border-slate-200 rounded-xl pl-8 focus-visible:ring-slate-400"
              />
            </div>
          </div>

          {/* Task Type */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-slate-700">
              Тип задания <span className="text-red-500">*</span>
            </Label>
            <Select
              value={formData.taskType}
              onValueChange={(value) =>
                setFormData((prev) => ({ ...prev, taskType: value }))
              }
            >
              <SelectTrigger className="h-11 bg-white border-slate-200 rounded-xl focus:ring-slate-400">
                <SelectValue placeholder="Выберите тип задания" />
              </SelectTrigger>
              <SelectContent className="rounded-xl">
                {TASK_TYPES.map((type) => (
                  <SelectItem key={type} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description" className="text-sm font-medium text-slate-700">
              Описание задания <span className="text-red-500">*</span>
            </Label>
            <Textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              placeholder="Опишите задание подробно: что нужно сделать, какие требования..."
              required
              rows={4}
              className="bg-white border-slate-200 rounded-xl resize-none focus-visible:ring-slate-400"
            />
          </div>

          {/* Budget */}
          <div className="space-y-2">
            <Label htmlFor="budget" className="text-sm font-medium text-slate-700">
              Бюджет
            </Label>
            <Input
              id="budget"
              name="budget"
              value={formData.budget}
              onChange={handleChange}
              placeholder="Например: 5000 руб, по договорённости"
              className="h-11 bg-white border-slate-200 rounded-xl focus-visible:ring-slate-400"
            />
          </div>

          {/* Deadline */}
          <div className="space-y-2">
            <Label htmlFor="deadline" className="text-sm font-medium text-slate-700">
              Срок выполнения
            </Label>
            <Input
              id="deadline"
              name="deadline"
              value={formData.deadline}
              onChange={handleChange}
              placeholder="Например: до 15 апреля, срочно, 2 дня"
              className="h-11 bg-white border-slate-200 rounded-xl focus-visible:ring-slate-400"
            />
          </div>

          {/* Contacts */}
          <div className="space-y-2">
            <Label htmlFor="contacts" className="text-sm font-medium text-slate-700">
              Доп. контакты
            </Label>
            <Input
              id="contacts"
              name="contacts"
              value={formData.contacts}
              onChange={handleChange}
              placeholder="Телефон, почта или другие контакты"
              className="h-11 bg-white border-slate-200 rounded-xl focus-visible:ring-slate-400"
            />
          </div>

          {/* Submit Button */}
          <div className="pt-2 pb-6">
            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full h-12 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-base transition-all active:scale-[0.98]"
            >
              {isSubmitting ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Отправка...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Send className="w-5 h-5" />
                  Отправить анкету
                </div>
              )}
            </Button>
          </div>
        </form>

        {/* Info Card */}
        <Card className="border-slate-200/60 bg-slate-50/50 mt-2">
          <CardContent className="p-4">
            <p className="text-xs text-slate-500 text-center leading-relaxed">
              Заполните анкету, и она придёт администратору.
              Поля со звёздочкой (<span className="text-red-500">*</span>) обязательны.
            </p>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
