import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const {
      name,
      username,
      taskType,
      description,
      budget,
      deadline,
      contacts,
    } = body;

    // Validate required fields
    if (!name || !description || !taskType) {
      return NextResponse.json(
        { error: "Заполните обязательные поля: имя, тип задания, описание" },
        { status: 400 }
      );
    }

    const botToken = process.env.BOT_TOKEN;
    const adminChatId = process.env.ADMIN_CHAT_ID;

    if (!botToken || !adminChatId) {
      return NextResponse.json(
        { error: "Сервер не настроен. Отсутствуют BOT_TOKEN или ADMIN_CHAT_ID." },
        { status: 500 }
      );
    }

    // Format the message
    const message = `📋 <b>Новая анкета на доп задание</b>

👤 <b>Имя:</b> ${escapeHtml(name)}
${username ? `🆔 <b>Telegram:</b> @${escapeHtml(username.replace("@", ""))}` : ""}

📌 <b>Тип задания:</b> ${escapeHtml(taskType)}

📝 <b>Описание:</b>
${escapeHtml(description)}

${budget ? `💰 <b>Бюджет:</b> ${escapeHtml(budget)}` : ""}
${deadline ? `⏰ <b>Срок:</b> ${escapeHtml(deadline)}` : ""}
${contacts ? `📞 <b>Контакты:</b> ${escapeHtml(contacts)}` : ""}`;

    // Send message via Telegram Bot API
    const telegramUrl = `https://api.telegram.org/bot${botToken}/sendMessage`;

    const response = await fetch(telegramUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: adminChatId,
        text: message,
        parse_mode: "HTML",
      }),
    });

    const result = await response.json();

    if (!result.ok) {
      console.error("Telegram API error:", result);
      return NextResponse.json(
        { error: "Не удалось отправить сообщение в Telegram" },
        { status: 500 }
      );
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Submit error:", error);
    return NextResponse.json(
      { error: "Внутренняя ошибка сервера" },
      { status: 500 }
    );
  }
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}
